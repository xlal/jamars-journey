JAMAR'S JOURNEY — 8-Bit Space Adventure

Run:
- Open index.html in a modern desktop or mobile browser.
- No build step or server is required.

Controls:
- Desktop: Arrow keys or WASD to move. P pauses, M toggles master mute.
- Mobile: drag directly on the playfield or use the directional buttons.
- Automatic firing is always enabled.
- Music/SFX toggles are on screen. Audio starts after pressing START GAME due to browser audio rules.

Notes:
- High score is stored locally in this browser.
- Internet connection is not required.


Permanent header credit: MADE BY JUN SEOB HAN (next to 8-BIT SPACE ADVENTURE).
